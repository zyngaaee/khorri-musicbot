

module.exports = {
  TOKEN: "MTQxMzU1OTAwNTY1NzQzNjMyMA.GVIr2b.YYHAJBVTQNR9Y3DueHja16r9cN4we0MiaEjtQQ",
  language: "en",
  ownerID: ["1178546425018187820"], 
  mongodbUri : "mongodb+srv://malayalidev:ponnumonu555@malaualidev.dvyvdba.mongodb.net/?appName=malaualidev",
  spotifyClientId : "d92baed9605a45a39ed7c2a2d960b1c1",
  spotifyClientSecret : "e9b29f6739de4315bc03b6d8a8e93b03",
  spotifyRedirectUri: "https://your-domain.example/spotify/callback",
  setupFilePath: './commands/setup.json',
  commandsDir: './commands',  
  embedColor: "#e11d2e",
  customEmoji: true,  // true = use custom emoji IDs from emoji.js, false = use default unicode
  emojiTheme: "redwhite", // active custom emoji theme key in emoji.js
  helpBannerUrl: "https://i.ibb.co/GfTxbJfC/7-edited.png", // Optional: set a direct image URL to show an inline banner in /help
  activityName: "LUNA", 
  activityType: "LISTENING",  // Available activity types : LISTENING , PLAYING
  SupportServer: "https://discord.gg/xQF9f9yUEM",
  embedTimeout: 5,
  showProgressBar: false,  // Show progress bar in track embed
  showVisualizer: false,  // Show visualizer on music card (disabled for low-memory optimization)
  generateSongCard: true,  // custom song card image, if false uses thumbnail
  metadataTag: true,  // If true, always show Song Details even when the card image is present
  lowMemoryMode: true,   // Performance optimizations for low-memory environments (512MB RAM)
  errorLog: "", 
  nodes: [
      {
      name: "OGTomz",
      password: "swlavapass",
      host: "node.uoaio.xyz",
      port: 20050,
      secure: false
    }
  ]
}
